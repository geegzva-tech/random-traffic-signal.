package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.SignalColor
import com.example.viewmodel.TrafficSignalViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun testAppStrings() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Random Traffic Signal", appName)
        assertEquals("RED", context.getString(R.string.signal_red))
        assertEquals("YELLOW", context.getString(R.string.signal_yellow))
        assertEquals("GREEN", context.getString(R.string.signal_green))
    }

    @Test
    fun testTrafficSignalInitialRandomState() {
        val viewModel = TrafficSignalViewModel()
        val state = viewModel.uiState.value

        assertNotNull(state.activeColor)
        assertTrue(state.isRunning)
        assertTrue(state.totalDurationMs in 2000L..8000L)
        assertTrue(state.remainingTimeMs in 1L..8000L)
    }

    @Test
    fun testToggleStartPause() {
        val viewModel = TrafficSignalViewModel()
        assertTrue(viewModel.uiState.value.isRunning)

        viewModel.toggleStartPause()
        assertEquals(false, viewModel.uiState.value.isRunning)

        viewModel.toggleStartPause()
        assertEquals(true, viewModel.uiState.value.isRunning)
    }

    @Test
    fun testRandomChangeNowAvoidsImmediateRepeat() {
        val viewModel = TrafficSignalViewModel()
        val initialColor = viewModel.uiState.value.activeColor

        viewModel.changeToNextRandomSignal(userInitiated = true)
        val nextColor = viewModel.uiState.value.activeColor

        assertNotEquals(initialColor, nextColor)
        assertTrue(viewModel.uiState.value.totalSwitches >= 2)
    }
}

