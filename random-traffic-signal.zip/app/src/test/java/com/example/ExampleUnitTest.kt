package com.example

import com.example.model.SignalColor
import com.example.model.TrafficSignalUiState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testSignalColorAttributes() {
        assertEquals("RED", SignalColor.RED.label)
        assertEquals("STOP", SignalColor.RED.actionText)

        assertEquals("YELLOW", SignalColor.YELLOW.label)
        assertEquals("GET READY", SignalColor.YELLOW.actionText)

        assertEquals("GREEN", SignalColor.GREEN.label)
        assertEquals("GO", SignalColor.GREEN.actionText)
    }

    @Test
    fun testProgressAndDurationFormatting() {
        val state = TrafficSignalUiState(
            totalDurationMs = 5000L,
            remainingTimeMs = 2500L
        )

        assertEquals(0.5f, state.progress, 0.01f)
        assertEquals("3s", state.remainingSecondsFormatted)
        assertEquals("2.5s", state.remainingTimeDetailed)
    }

    @Test
    fun testProgressBoundaries() {
        val zeroState = TrafficSignalUiState(
            totalDurationMs = 4000L,
            remainingTimeMs = 0L
        )
        assertEquals(0f, zeroState.progress, 0.001f)

        val fullState = TrafficSignalUiState(
            totalDurationMs = 4000L,
            remainingTimeMs = 4000L
        )
        assertEquals(1f, fullState.progress, 0.001f)
    }
}

