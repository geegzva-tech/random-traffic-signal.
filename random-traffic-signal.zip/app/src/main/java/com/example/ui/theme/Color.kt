package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Traffic Signal Colors (Lit / Active)
val SignalRed = Color(0xFFFF2A3B)
val SignalRedGlow = Color(0x66FF2A3B)
val SignalRedCore = Color(0xFFFF858F)

val SignalYellow = Color(0xFFFFB800)
val SignalYellowGlow = Color(0x66FFB800)
val SignalYellowCore = Color(0xFFFFE082)

val SignalGreen = Color(0xFF00E676)
val SignalGreenGlow = Color(0x6600E676)
val SignalGreenCore = Color(0xFFB9F6CA)

// Inactive / Dim Lamp Colors
val SignalRedDim = Color(0xFF2B1214)
val SignalYellowDim = Color(0xFF2D2510)
val SignalGreenDim = Color(0xFF0E2918)

// Housing & Modern Dark Theme
val BackgroundDark = Color(0xFF0E1116)
val BackgroundSurface = Color(0xFF161B22)
val BackgroundCard = Color(0xFF212631)
val HousingDark = Color(0xFF1B1E26)
val HousingBorder = Color(0xFF323846)
val HousingVisor = Color(0xFF262B36)
val TextPrimary = Color(0xFFF0F3F6)
val TextSecondary = Color(0xFF8B949E)
val AccentBlue = Color(0xFF388BFD)

