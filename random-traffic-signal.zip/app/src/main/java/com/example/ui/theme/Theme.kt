package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TrafficSignalColorScheme = darkColorScheme(
  primary = AccentBlue,
  onPrimary = Color.White,
  primaryContainer = Color(0xFF1E3A5F),
  onPrimaryContainer = Color(0xFFCBE5FF),
  secondary = SignalYellow,
  onSecondary = Color.Black,
  tertiary = SignalGreen,
  onTertiary = Color.Black,
  background = BackgroundDark,
  onBackground = TextPrimary,
  surface = BackgroundSurface,
  onSurface = TextPrimary,
  surfaceVariant = BackgroundCard,
  onSurfaceVariant = TextSecondary,
  outline = HousingBorder
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = TrafficSignalColorScheme,
    typography = Typography,
    content = content
  )
}

