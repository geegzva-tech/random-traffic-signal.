package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SignalColor
import com.example.sound.FeedbackHelper
import com.example.ui.components.SignalSettingsSheet
import com.example.ui.components.SignalStatusBanner
import com.example.ui.components.TrafficSignalBox
import com.example.ui.components.TrafficSignalControls
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.TrafficSignalViewModel

@Composable
fun TrafficSignalScreen(
    viewModel: TrafficSignalViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    var showSettingsSheet by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val feedbackHelper = remember { FeedbackHelper(context) }

    DisposableEffect(Unit) {
        onDispose {
            feedbackHelper.release()
        }
    }

    // Keep screen on when requested
    val currentView = LocalView.current
    DisposableEffect(uiState.keepScreenOn) {
        currentView.keepScreenOn = uiState.keepScreenOn
        onDispose {
            currentView.keepScreenOn = false
        }
    }

    // Handle audio/haptic feedback on signal change
    LaunchedEffect(Unit) {
        viewModel.signalChangeEvent.collect { newColor ->
            feedbackHelper.playSignalChange(
                color = newColor,
                soundEnabled = uiState.soundEnabled,
                hapticsEnabled = uiState.hapticsEnabled
            )
        }
    }

    Scaffold(
        containerColor = BackgroundDark,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF13171F),
                            BackgroundDark,
                            Color(0xFF090A0D)
                        )
                    )
                )
                .drawBehind {
                    // Subtle ambient lighting behind the traffic light
                    val centerOffset = Offset(size.width / 2f, size.height * 0.38f)
                    val glowColor = when (uiState.activeColor) {
                        SignalColor.RED -> Color(0x18FF2A3B)
                        SignalColor.YELLOW -> Color(0x18FFB800)
                        SignalColor.GREEN -> Color(0x1800E676)
                    }
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(glowColor, Color.Transparent),
                            center = centerOffset,
                            radius = size.width * 0.7f
                        )
                    )
                }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top App Header
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                ) {
                    Text(
                        text = "RANDOM TRAFFIC SIGNAL",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.5.sp,
                        color = TextPrimary
                    )
                    Text(
                        text = if (uiState.isRunning) "Automatic Random Mode Active" else "Timer Paused",
                        fontSize = 12.sp,
                        color = if (uiState.isRunning) Color(0xFF64B5F6) else Color(0xFFFFB74D),
                        fontWeight = FontWeight.Medium
                    )
                }

                // Center Traffic Signal Housing
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    TrafficSignalBox(
                        activeColor = uiState.activeColor,
                        onLightClick = { selectedColor ->
                            viewModel.selectSignalDirectly(selectedColor)
                        }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Status Banner (Signal label & Countdown)
                SignalStatusBanner(
                    state = uiState,
                    modifier = Modifier.widthIn(max = 420.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Bottom Controls (START/PAUSE & RANDOM CHANGE NOW)
                TrafficSignalControls(
                    state = uiState,
                    onToggleStartPause = { viewModel.toggleStartPause() },
                    onRandomChangeNow = { viewModel.changeToNextRandomSignal(userInitiated = true) },
                    onOpenSettings = { showSettingsSheet = true },
                    modifier = Modifier.widthIn(max = 420.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))
            }
        }

        // Settings & Customization Sheet
        if (showSettingsSheet) {
            SignalSettingsSheet(
                state = uiState,
                onDismiss = { showSettingsSheet = false },
                onDurationRangeChange = { minSec, maxSec ->
                    viewModel.setDurationRange(minSec, maxSec)
                },
                onToggleSound = { viewModel.toggleSound() },
                onToggleHaptics = { viewModel.toggleHaptics() },
                onToggleKeepScreenOn = { viewModel.toggleKeepScreenOn() },
                onResetStats = { viewModel.resetStats() }
            )
        }
    }
}
