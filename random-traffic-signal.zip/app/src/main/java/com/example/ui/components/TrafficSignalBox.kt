package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.model.SignalColor
import com.example.ui.theme.HousingBorder
import com.example.ui.theme.HousingDark
import com.example.ui.theme.HousingVisor
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalGreenCore
import com.example.ui.theme.SignalGreenDim
import com.example.ui.theme.SignalGreenGlow
import com.example.ui.theme.SignalRed
import com.example.ui.theme.SignalRedCore
import com.example.ui.theme.SignalRedDim
import com.example.ui.theme.SignalRedGlow
import com.example.ui.theme.SignalYellow
import com.example.ui.theme.SignalYellowCore
import com.example.ui.theme.SignalYellowDim
import com.example.ui.theme.SignalYellowGlow

@Composable
fun TrafficSignalBox(
    activeColor: SignalColor,
    onLightClick: (SignalColor) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
    ) {
        // Main Traffic Signal Housing
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .testTag("signal_box")
                .shadow(
                    elevation = 24.dp,
                    shape = RoundedCornerShape(32.dp),
                    spotColor = Color.Black
                )
                .clip(RoundedCornerShape(32.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            HousingDark,
                            Color(0xFF14171E),
                            Color(0xFF0F1116)
                        )
                    )
                )
                .border(
                    width = 2.5.dp,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            HousingBorder,
                            Color(0xFF222733),
                            HousingBorder
                        )
                    ),
                    shape = RoundedCornerShape(32.dp)
                )
                .padding(horizontal = 22.dp, vertical = 26.dp)
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // RED LAMP
                SignalLamp(
                    color = SignalColor.RED,
                    isActive = activeColor == SignalColor.RED,
                    activeColor = SignalRed,
                    activeCoreColor = SignalRedCore,
                    glowColor = SignalRedGlow,
                    dimColor = SignalRedDim,
                    onClick = { onLightClick(SignalColor.RED) },
                    modifier = Modifier.testTag("light_red")
                )

                // YELLOW LAMP
                SignalLamp(
                    color = SignalColor.YELLOW,
                    isActive = activeColor == SignalColor.YELLOW,
                    activeColor = SignalYellow,
                    activeCoreColor = SignalYellowCore,
                    glowColor = SignalYellowGlow,
                    dimColor = SignalYellowDim,
                    onClick = { onLightClick(SignalColor.YELLOW) },
                    modifier = Modifier.testTag("light_yellow")
                )

                // GREEN LAMP
                SignalLamp(
                    color = SignalColor.GREEN,
                    isActive = activeColor == SignalColor.GREEN,
                    activeColor = SignalGreen,
                    activeCoreColor = SignalGreenCore,
                    glowColor = SignalGreenGlow,
                    dimColor = SignalGreenDim,
                    onClick = { onLightClick(SignalColor.GREEN) },
                    modifier = Modifier.testTag("light_green")
                )
            }
        }

        // Metal Mounting Pole below housing
        Box(
            modifier = Modifier
                .width(28.dp)
                .height(48.dp)
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFF16181F),
                            Color(0xFF3A4150),
                            Color(0xFF1F232B),
                            Color(0xFF121419)
                        )
                    )
                )
                .border(
                    width = 1.dp,
                    color = Color(0xFF2E3442)
                )
        )

        // Pole base collar
        Box(
            modifier = Modifier
                .width(52.dp)
                .height(10.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFF252A36))
                .border(1.dp, Color(0xFF384050), RoundedCornerShape(4.dp))
        )
    }
}

@Composable
private fun SignalLamp(
    color: SignalColor,
    isActive: Boolean,
    activeColor: Color,
    activeCoreColor: Color,
    glowColor: Color,
    dimColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Smooth transitions for illumination
    val transitionProgress by animateFloatAsState(
        targetValue = if (isActive) 1f else 0f,
        animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing),
        label = "lamp_glow_transition"
    )

    // Subtle gentle pulse when active
    val infiniteTransition = rememberInfiniteTransition(label = "active_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    val currentGlowAlpha = if (isActive) pulseAlpha else 0f

    val lampSize = 92.dp
    val interactionSource = remember { MutableInteractionSource() }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .semantics { contentDescription = "${color.label} traffic light, is ${if (isActive) "ON" else "OFF"}" }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
    ) {
        // Sun Visor / Hood above the lamp
        Canvas(
            modifier = Modifier
                .size(width = lampSize + 20.dp, height = 32.dp)
                .align(Alignment.TopCenter)
                .offset(y = (-14).dp)
        ) {
            val width = size.width
            val height = size.height

            val visorPath = Path().apply {
                moveTo(6f, height)
                cubicTo(
                    width * 0.25f, 0f,
                    width * 0.75f, 0f,
                    width - 6f, height
                )
                lineTo(width, height)
                cubicTo(
                    width * 0.75f, -6f,
                    width * 0.25f, -6f,
                    0f, height
                )
                close()
            }

            drawPath(
                path = visorPath,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        HousingVisor,
                        Color(0xFF161820)
                    )
                )
            )

            // Outer rim line
            drawPath(
                path = visorPath,
                color = HousingBorder,
                style = Stroke(width = 2f)
            )
        }

        // Bloom Glow Effect Behind the Active Light
        if (transitionProgress > 0.01f) {
            Box(
                modifier = Modifier
                    .size(lampSize + 36.dp)
                    .drawBehind {
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    glowColor.copy(alpha = 0.55f * transitionProgress * currentGlowAlpha),
                                    glowColor.copy(alpha = 0.25f * transitionProgress * currentGlowAlpha),
                                    Color.Transparent
                                ),
                                center = center,
                                radius = size.minDimension / 1.8f
                            )
                        )
                    }
            )
        }

        // Deep recessed bezel ring
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(lampSize + 10.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF1E222C),
                            Color(0xFF0C0E12)
                        )
                    )
                )
                .border(2.dp, Color(0xFF2C3240), CircleShape)
        ) {
            // Lens Glass Canvas
            Canvas(
                modifier = Modifier
                    .size(lampSize)
                    .clip(CircleShape)
            ) {
                val radius = size.minDimension / 2f
                val centerOffset = Offset(size.width / 2f, size.height / 2f)

                if (transitionProgress > 0.01f) {
                    // --- ACTIVE STATE ---
                    // Deep saturated base
                    drawCircle(
                        color = activeColor,
                        radius = radius,
                        center = centerOffset
                    )

                    // Brilliant radial core & highlight
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                activeCoreColor.copy(alpha = transitionProgress),
                                activeColor.copy(alpha = transitionProgress),
                                activeColor.copy(alpha = 0.85f * transitionProgress)
                            ),
                            center = centerOffset.copy(
                                x = centerOffset.x - radius * 0.15f,
                                y = centerOffset.y - radius * 0.2f
                            ),
                            radius = radius * 1.05f
                        ),
                        radius = radius,
                        center = centerOffset
                    )

                    // Optical Fresnel Lens Ring Texture
                    for (i in 1..4) {
                        val ringRadius = radius * (i / 5f)
                        drawCircle(
                            color = Color.White.copy(alpha = 0.18f * transitionProgress),
                            radius = ringRadius,
                            center = centerOffset,
                            style = Stroke(width = 2.5f)
                        )
                    }

                    // Bright specular glint
                    drawOval(
                        color = Color.White.copy(alpha = 0.45f * transitionProgress),
                        topLeft = Offset(centerOffset.x - radius * 0.45f, centerOffset.y - radius * 0.65f),
                        size = Size(radius * 0.7f, radius * 0.35f)
                    )
                } else {
                    // --- INACTIVE STATE ---
                    // Dark tinted lens glass
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                dimColor,
                                Color(0xFF090A0D)
                            ),
                            center = centerOffset.copy(
                                x = centerOffset.x - radius * 0.2f,
                                y = centerOffset.y - radius * 0.25f
                            ),
                            radius = radius
                        ),
                        radius = radius,
                        center = centerOffset
                    )

                    // Concentric rings visible even when turned off (realistic glass optics)
                    for (i in 1..4) {
                        val ringRadius = radius * (i / 5f)
                        drawCircle(
                            color = Color(0xFF222630).copy(alpha = 0.5f),
                            radius = ringRadius,
                            center = centerOffset,
                            style = Stroke(width = 1.5f)
                        )
                    }

                    // Faint ambient specular glass reflection
                    drawOval(
                        color = Color.White.copy(alpha = 0.08f),
                        topLeft = Offset(centerOffset.x - radius * 0.45f, centerOffset.y - radius * 0.6f),
                        size = Size(radius * 0.6f, radius * 0.3f)
                    )
                }

                // Inner rim vignette shadow
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.4f)
                        ),
                        center = centerOffset,
                        radius = radius
                    ),
                    radius = radius,
                    center = centerOffset
                )
            }
        }
    }
}
