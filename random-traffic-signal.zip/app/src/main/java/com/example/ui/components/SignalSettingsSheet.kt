package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ScreenLockPortrait
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.SignalColor
import com.example.model.TrafficSignalUiState
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.BackgroundCard
import com.example.ui.theme.BackgroundSurface
import com.example.ui.theme.HousingBorder
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalRed
import com.example.ui.theme.SignalYellow
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SignalSettingsSheet(
    state: TrafficSignalUiState,
    onDismiss: () -> Unit,
    onDurationRangeChange: (Int, Int) -> Unit,
    onToggleSound: () -> Unit,
    onToggleHaptics: () -> Unit,
    onToggleKeepScreenOn: () -> Unit,
    onResetStats: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = BackgroundSurface,
        scrimColor = Color.Black.copy(alpha = 0.65f),
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Signal Settings & Stats",
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close settings sheet",
                        tint = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Duration Presets Section
            Text(
                text = "RANDOM DURATION PRESETS",
                color = TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PresetChip(
                    title = "Fast",
                    subtitle = "1 - 4s",
                    isSelected = state.minDurationSec == 1 && state.maxDurationSec == 4,
                    onClick = { onDurationRangeChange(1, 4) }
                )
                PresetChip(
                    title = "Standard",
                    subtitle = "2 - 8s",
                    isSelected = state.minDurationSec == 2 && state.maxDurationSec == 8,
                    onClick = { onDurationRangeChange(2, 8) }
                )
                PresetChip(
                    title = "Slow",
                    subtitle = "4 - 15s",
                    isSelected = state.minDurationSec == 4 && state.maxDurationSec == 15,
                    onClick = { onDurationRangeChange(4, 15) }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Sliders for Min and Max Seconds
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(BackgroundCard)
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Custom Range: ${state.minDurationSec}s to ${state.maxDurationSec}s",
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    // Min duration slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Minimum duration", color = TextSecondary, fontSize = 12.sp)
                            Text("${state.minDurationSec} sec", color = AccentBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = state.minDurationSec.toFloat(),
                            onValueChange = { newMin ->
                                val minVal = newMin.roundToInt()
                                val maxVal = maxOf(minVal, state.maxDurationSec)
                                onDurationRangeChange(minVal, maxVal)
                            },
                            valueRange = 1f..15f,
                            steps = 13,
                            colors = SliderDefaults.colors(
                                thumbColor = AccentBlue,
                                activeTrackColor = AccentBlue,
                                inactiveTrackColor = Color(0xFF2E3444)
                            )
                        )
                    }

                    // Max duration slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Maximum duration", color = TextSecondary, fontSize = 12.sp)
                            Text("${state.maxDurationSec} sec", color = AccentBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = state.maxDurationSec.toFloat(),
                            onValueChange = { newMax ->
                                val maxVal = newMax.roundToInt()
                                val minVal = minOf(state.minDurationSec, maxVal)
                                onDurationRangeChange(minVal, maxVal)
                            },
                            valueRange = 2f..30f,
                            steps = 27,
                            colors = SliderDefaults.colors(
                                thumbColor = AccentBlue,
                                activeTrackColor = AccentBlue,
                                inactiveTrackColor = Color(0xFF2E3444)
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Toggles (Sound, Haptics, Screen On)
            Text(
                text = "FEEDBACK & DISPLAY",
                color = TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(BackgroundCard)
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Column {
                    ToggleRow(
                        icon = Icons.Default.VolumeUp,
                        label = stringResource(R.string.sound_effects),
                        isChecked = state.soundEnabled,
                        onCheckedChange = { onToggleSound() }
                    )
                    HorizontalDivider(color = HousingBorder.copy(alpha = 0.5f), thickness = 0.8.dp)
                    ToggleRow(
                        icon = Icons.Default.Vibration,
                        label = stringResource(R.string.haptics),
                        isChecked = state.hapticsEnabled,
                        onCheckedChange = { onToggleHaptics() }
                    )
                    HorizontalDivider(color = HousingBorder.copy(alpha = 0.5f), thickness = 0.8.dp)
                    ToggleRow(
                        icon = Icons.Default.ScreenLockPortrait,
                        label = stringResource(R.string.keep_screen_on),
                        isChecked = state.keepScreenOn,
                        onCheckedChange = { onToggleKeepScreenOn() }
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Statistics Section
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SESSION STATISTICS",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                TextButton(onClick = onResetStats) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reset statistics",
                        modifier = Modifier.size(14.dp),
                        tint = AccentBlue
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Reset", color = AccentBlue, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(BackgroundCard)
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(stringResource(R.string.total_switches), color = TextSecondary, fontSize = 13.sp)
                        Text("${state.totalSwitches}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    // Recent History Sequence Dots
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Recent Sequence:", color = TextSecondary, fontSize = 12.sp)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            state.recentHistory.take(8).forEach { color ->
                                val dotColor = when (color) {
                                    SignalColor.RED -> SignalRed
                                    SignalColor.YELLOW -> SignalYellow
                                    SignalColor.GREEN -> SignalGreen
                                }
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clip(CircleShape)
                                        .background(dotColor)
                                        .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun PresetChip(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (isSelected) AccentBlue else BackgroundCard)
            .border(
                1.dp,
                if (isSelected) AccentBlue else HousingBorder,
                RoundedCornerShape(14.dp)
            )
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth(if (title == "Fast" || title == "Standard") 0.3f else 1f)
        ) {
            TextButton(
                onClick = onClick,
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = title,
                        color = if (isSelected) Color.White else TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = subtitle,
                        color = if (isSelected) Color.White.copy(alpha = 0.8f) else TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun ToggleRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = TextSecondary,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = label,
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = AccentBlue,
                uncheckedThumbColor = TextSecondary,
                uncheckedTrackColor = Color(0xFF262B36)
            )
        )
    }
}
