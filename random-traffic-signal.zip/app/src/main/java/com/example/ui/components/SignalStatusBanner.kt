package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.SignalColor
import com.example.model.TrafficSignalUiState
import com.example.ui.theme.BackgroundCard
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalRed
import com.example.ui.theme.SignalYellow
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun SignalStatusBanner(
    state: TrafficSignalUiState,
    modifier: Modifier = Modifier
) {
    val activeColor = state.activeColor
    val (accentColor, bgTint, labelRes, actionRes) = when (activeColor) {
        SignalColor.RED -> Quad(
            SignalRed,
            SignalRed.copy(alpha = 0.15f),
            R.string.signal_red,
            R.string.status_stop
        )
        SignalColor.YELLOW -> Quad(
            SignalYellow,
            SignalYellow.copy(alpha = 0.15f),
            R.string.signal_yellow,
            R.string.status_ready
        )
        SignalColor.GREEN -> Quad(
            SignalGreen,
            SignalGreen.copy(alpha = 0.15f),
            R.string.signal_green,
            R.string.status_go
        )
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        // Current Signal Badge (e.g. RED • STOP)
        AnimatedContent(
            targetState = activeColor,
            transitionSpec = {
                fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(180))
            },
            label = "status_badge_anim"
        ) { color ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier
                    .testTag("signal_status_text")
                    .clip(RoundedCornerShape(100.dp))
                    .background(bgTint)
                    .border(1.5.dp, accentColor.copy(alpha = 0.6f), RoundedCornerShape(100.dp))
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            ) {
                // Colored Indicator dot
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(accentColor)
                )

                Spacer(modifier = Modifier.width(10.dp))

                Text(
                    text = stringResource(labelRes),
                    color = accentColor,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp
                )

                Text(
                    text = " • ",
                    color = TextSecondary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = stringResource(actionRes),
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp
                )
            }
        }

        // Countdown Card
        Box(
            modifier = Modifier
                .testTag("countdown_display")
                .clip(RoundedCornerShape(18.dp))
                .background(BackgroundCard.copy(alpha = 0.7f))
                .border(1.dp, Color(0xFF2C3240), RoundedCornerShape(18.dp))
                .padding(horizontal = 20.dp, vertical = 10.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = if (state.isRunning) {
                            stringResource(R.string.countdown_label)
                        } else {
                            "Signal Paused at"
                        },
                        color = TextSecondary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Text(
                        text = state.remainingTimeDetailed,
                        color = if (state.isRunning) accentColor else TextSecondary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Smooth Progress Bar
                LinearProgressIndicator(
                    progress = { state.progress },
                    modifier = Modifier
                        .width(190.dp)
                        .height(5.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = if (state.isRunning) accentColor else Color.Gray,
                    trackColor = Color(0xFF141720)
                )
            }
        }
    }
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
