package com.example.sound

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.example.model.SignalColor

class FeedbackHelper(context: Context) {
    private val appContext = context.applicationContext
    private var toneGenerator: ToneGenerator? = null

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 75)
        } catch (_: Exception) {
            toneGenerator = null
        }
    }

    fun playSignalChange(color: SignalColor, soundEnabled: Boolean, hapticsEnabled: Boolean) {
        if (soundEnabled) {
            try {
                val toneType = when (color) {
                    SignalColor.RED -> ToneGenerator.TONE_PROP_NACK
                    SignalColor.YELLOW -> ToneGenerator.TONE_PROP_BEEP
                    SignalColor.GREEN -> ToneGenerator.TONE_PROP_ACK
                }
                toneGenerator?.startTone(toneType, 70)
            } catch (_: Exception) {
                // Ignore audio errors gracefully
            }
        }

        if (hapticsEnabled) {
            try {
                vibrateDevice()
            } catch (_: Exception) {
                // Ignore vibration errors gracefully
            }
        }
    }

    private fun vibrateDevice() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = appContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            val effect = VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
            val combined = CombinedVibration.createParallel(effect)
            vibratorManager?.vibrate(combined)
        } else {
            @Suppress("DEPRECATION")
            val vibrator = appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(40)
            }
        }
    }

    fun release() {
        try {
            toneGenerator?.release()
        } catch (_: Exception) {
        }
        toneGenerator = null
    }
}
