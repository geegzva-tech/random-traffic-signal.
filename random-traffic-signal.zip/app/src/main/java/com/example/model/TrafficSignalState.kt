package com.example.model

enum class SignalColor(
    val label: String,
    val actionText: String
) {
    RED("RED", "STOP"),
    YELLOW("YELLOW", "GET READY"),
    GREEN("GREEN", "GO")
}

data class TrafficSignalUiState(
    val activeColor: SignalColor = SignalColor.RED,
    val isRunning: Boolean = true,
    val totalDurationMs: Long = 4000L,
    val remainingTimeMs: Long = 4000L,
    val minDurationSec: Int = 2,
    val maxDurationSec: Int = 8,
    val totalSwitches: Int = 0,
    val redDurationMs: Long = 0L,
    val yellowDurationMs: Long = 0L,
    val greenDurationMs: Long = 0L,
    val soundEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val keepScreenOn: Boolean = true,
    val recentHistory: List<SignalColor> = listOf(SignalColor.RED)
) {
    val progress: Float
        get() = if (totalDurationMs > 0) {
            (remainingTimeMs.toFloat() / totalDurationMs.toFloat()).coerceIn(0f, 1f)
        } else 0f

    val remainingSecondsFormatted: String
        get() {
            val seconds = (remainingTimeMs + 999) / 1000
            return "${seconds.coerceAtLeast(0)}s"
        }

    val remainingTimeDetailed: String
        get() {
            val sec = remainingTimeMs / 1000f
            return String.format(java.util.Locale.US, "%.1fs", sec.coerceAtLeast(0f))
        }
}
