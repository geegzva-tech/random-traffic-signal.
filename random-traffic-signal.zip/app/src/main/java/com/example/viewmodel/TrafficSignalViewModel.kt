package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.SignalColor
import com.example.model.TrafficSignalUiState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

class TrafficSignalViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(createInitialState())
    val uiState: StateFlow<TrafficSignalUiState> = _uiState.asStateFlow()

    private val _signalChangeEvent = MutableSharedFlow<SignalColor>(extraBufferCapacity = 1)
    val signalChangeEvent: SharedFlow<SignalColor> = _signalChangeEvent.asSharedFlow()

    private var timerJob: Job? = null
    private val tickIntervalMs = 50L

    init {
        startTimer()
    }

    private fun createInitialState(): TrafficSignalUiState {
        // Randomly choose initial signal and duration (2-8 seconds)
        val initialColor = SignalColor.entries.random()
        val minSec = 2
        val maxSec = 8
        val initialDurationMs = Random.nextLong(minSec.toLong(), (maxSec + 1).toLong()) * 1000L

        return TrafficSignalUiState(
            activeColor = initialColor,
            isRunning = true,
            totalDurationMs = initialDurationMs,
            remainingTimeMs = initialDurationMs,
            minDurationSec = minSec,
            maxDurationSec = maxSec,
            totalSwitches = 1,
            recentHistory = listOf(initialColor)
        )
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (isActive) {
                delay(tickIntervalMs)
                if (_uiState.value.isRunning) {
                    val currentRemaining = _uiState.value.remainingTimeMs - tickIntervalMs
                    val currentColor = _uiState.value.activeColor

                    if (currentRemaining <= 0L) {
                        // Timer completed: automatically transition to a new random signal
                        changeToNextRandomSignal(userInitiated = false)
                    } else {
                        _uiState.update { state ->
                            state.copy(
                                remainingTimeMs = currentRemaining,
                                redDurationMs = state.redDurationMs + if (currentColor == SignalColor.RED) tickIntervalMs else 0L,
                                yellowDurationMs = state.yellowDurationMs + if (currentColor == SignalColor.YELLOW) tickIntervalMs else 0L,
                                greenDurationMs = state.greenDurationMs + if (currentColor == SignalColor.GREEN) tickIntervalMs else 0L
                            )
                        }
                    }
                }
            }
        }
    }

    /**
     * Changes to the next random signal and duration.
     * Avoids immediately repeating the same signal when possible.
     */
    fun changeToNextRandomSignal(userInitiated: Boolean = true) {
        val currentState = _uiState.value
        val possibleColors = SignalColor.entries.filter { it != currentState.activeColor }
        val nextColor = if (possibleColors.isNotEmpty()) {
            possibleColors.random()
        } else {
            SignalColor.entries.random()
        }

        val minSec = currentState.minDurationSec
        val maxSec = currentState.maxDurationSec.coerceAtLeast(minSec)
        val nextDurationMs = Random.nextLong(minSec.toLong(), (maxSec + 1).toLong()) * 1000L

        val updatedHistory = (listOf(nextColor) + currentState.recentHistory).take(12)

        _uiState.update { state ->
            state.copy(
                activeColor = nextColor,
                totalDurationMs = nextDurationMs,
                remainingTimeMs = nextDurationMs,
                totalSwitches = state.totalSwitches + 1,
                recentHistory = updatedHistory
            )
        }

        _signalChangeEvent.tryEmit(nextColor)
    }

    fun toggleStartPause() {
        _uiState.update { state ->
            state.copy(isRunning = !state.isRunning)
        }
    }

    fun setDurationRange(minSec: Int, maxSec: Int) {
        val safeMin = minSec.coerceIn(1, 30)
        val safeMax = maxSec.coerceIn(safeMin, 60)
        _uiState.update { state ->
            state.copy(
                minDurationSec = safeMin,
                maxDurationSec = safeMax
            )
        }
    }

    fun toggleSound() {
        _uiState.update { state ->
            state.copy(soundEnabled = !state.soundEnabled)
        }
    }

    fun toggleHaptics() {
        _uiState.update { state ->
            state.copy(hapticsEnabled = !state.hapticsEnabled)
        }
    }

    fun toggleKeepScreenOn() {
        _uiState.update { state ->
            state.copy(keepScreenOn = !state.keepScreenOn)
        }
    }

    fun selectSignalDirectly(color: SignalColor) {
        if (_uiState.value.activeColor == color) return
        val currentState = _uiState.value
        val minSec = currentState.minDurationSec
        val maxSec = currentState.maxDurationSec.coerceAtLeast(minSec)
        val nextDurationMs = Random.nextLong(minSec.toLong(), (maxSec + 1).toLong()) * 1000L

        val updatedHistory = (listOf(color) + currentState.recentHistory).take(12)

        _uiState.update { state ->
            state.copy(
                activeColor = color,
                totalDurationMs = nextDurationMs,
                remainingTimeMs = nextDurationMs,
                totalSwitches = state.totalSwitches + 1,
                recentHistory = updatedHistory
            )
        }
        _signalChangeEvent.tryEmit(color)
    }

    fun resetStats() {
        _uiState.update { state ->
            state.copy(
                totalSwitches = 1,
                redDurationMs = 0L,
                yellowDurationMs = 0L,
                greenDurationMs = 0L,
                recentHistory = listOf(state.activeColor)
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}
